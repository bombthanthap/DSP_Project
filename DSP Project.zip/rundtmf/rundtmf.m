% automated DTMF decoding from microphone
% free for sharing
% ver1 3.3.2019
% KU SRC
% ver2 30.10.2020
% by Montri P.
% by Group 1

clc
clear
close all

% initial hardware setup
fs = 44100; % sampling rate
rectime = 2; % second
data = record(rectime, fs);

% time variable
t=0:1/fs:length(data)/fs - 1/fs;

% FFT method to show in Frequency Domain
fx = fft(data, fs);
afx = abs(fx(1:end/2));

[magf fmax] = max(afx);
fmax1 = fmax - 1

afx(fmax-10:fmax+10) = min(afx);

[magf fmax] = max(afx);
fmax2 = fmax - 1

% show output
subplot(3,1,1);plot(t, data);
subplot(3,1,2);stem(afx(1:1500), 'm');


% Monkey 73 
if (abs(fmax1-fmax2) == 73)
  subplot(3,1,3); imshow('num1.png')
end

% Bear
if (abs(fmax1-fmax2) == 270)
  subplot(3,1,3); imshow('num2.png')
end

%Owl
if ((abs(fmax1-fmax2) >= 118) && (abs(fmax1-fmax2) <= 119))
  subplot(3,1,3); imshow('num3.png')
end
