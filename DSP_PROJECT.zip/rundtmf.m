% automated DTMF decoding from microphone
% free for sharing
% ver1 3.3.2019
% KU SRC
% ver2 30.10.2020
% by Montri P.
% by Group 1

clc
clear
close all

% initial hardware setup
fs = 44100; % sampling rate
rectime = 2; % second
data = record(rectime, fs);

% time variable
t=0:1/fs:length(data)/fs - 1/fs;

% FFT method to show in Frequency Domain
fx = fft(data, fs);
afx = abs(fx(1:end/2));

[magf fmax] = max(afx);
fmax1 = fmax - 1

afx(fmax-10:fmax+10) = min(afx);

[magf fmax] = max(afx);
fmax2 = fmax - 1

% show output
subplot(3,1,1);plot(t, data);
subplot(3,1,2);stem(afx(1:1500), 'm');
abs(fmax1-fmax2)

% Monkey 418
if ((abs(fmax1-fmax2) >= 414) && (abs(fmax1-fmax2) <= 426))
  subplot(3,1,3);
  imshow('Monkey.png');
end

% Bear
if ((abs(fmax1-fmax2) >=41) && (abs(fmax1-fmax2) <= 109))
  subplot(3,1,3); 
  imshow('Bear.png');
end

%Owl 98
if ((abs(fmax1-fmax2) >= 36) && (abs(fmax1-fmax2) <= 139))
  subplot(3,1,3);
  imshow('Owl.png');
end
